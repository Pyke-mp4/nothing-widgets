package com.nothingwidgets

import android.content.Context
import java.text.Collator
import java.time.ZoneId
import java.util.Locale

data class City(val name: String, val code: String, val zoneId: String) {
    val zone: ZoneId
        get() = try {
            ZoneId.of(zoneId)
        } catch (e: Exception) {
            ZoneId.of("UTC")
        }
}

object Cities {

    private val raw = listOf(
        City("Londres", "LON", "Europe/London"),
        City("Dublin", "DUB", "Europe/Dublin"),
        City("Lisbonne", "LIS", "Europe/Lisbon"),
        City("Madrid", "MAD", "Europe/Madrid"),
        City("Berlin", "BER", "Europe/Berlin"),
        City("Rome", "ROM", "Europe/Rome"),
        City("Amsterdam", "AMS", "Europe/Amsterdam"),
        City("Bruxelles", "BRU", "Europe/Brussels"),
        City("Zurich", "ZRH", "Europe/Zurich"),
        City("Stockholm", "STO", "Europe/Stockholm"),
        City("Varsovie", "WAW", "Europe/Warsaw"),
        City("Helsinki", "HEL", "Europe/Helsinki"),
        City("Athènes", "ATH", "Europe/Athens"),
        City("Istanbul", "IST", "Europe/Istanbul"),
        City("Moscou", "MOW", "Europe/Moscow"),
        City("Reykjavik", "KEF", "Atlantic/Reykjavik"),
        City("Casablanca", "CAS", "Africa/Casablanca"),
        City("Alger", "ALG", "Africa/Algiers"),
        City("Tunis", "TUN", "Africa/Tunis"),
        City("Le Caire", "CAI", "Africa/Cairo"),
        City("Dakar", "DKR", "Africa/Dakar"),
        City("Abidjan", "ABJ", "Africa/Abidjan"),
        City("Lagos", "LOS", "Africa/Lagos"),
        City("Nairobi", "NBO", "Africa/Nairobi"),
        City("Johannesburg", "JNB", "Africa/Johannesburg"),
        City("Saint-Denis (Réunion)", "RUN", "Indian/Reunion"),
        City("Dubaï", "DXB", "Asia/Dubai"),
        City("Riyad", "RUH", "Asia/Riyadh"),
        City("Tel Aviv", "TLV", "Asia/Jerusalem"),
        City("Téhéran", "THR", "Asia/Tehran"),
        City("Karachi", "KHI", "Asia/Karachi"),
        City("Delhi", "DEL", "Asia/Kolkata"),
        City("Dacca", "DAC", "Asia/Dhaka"),
        City("Bangkok", "BKK", "Asia/Bangkok"),
        City("Hô Chi Minh-Ville", "SGN", "Asia/Ho_Chi_Minh"),
        City("Jakarta", "JKT", "Asia/Jakarta"),
        City("Singapour", "SIN", "Asia/Singapore"),
        City("Hong Kong", "HKG", "Asia/Hong_Kong"),
        City("Shanghai", "SHA", "Asia/Shanghai"),
        City("Taipei", "TPE", "Asia/Taipei"),
        City("Manille", "MNL", "Asia/Manila"),
        City("Séoul", "SEL", "Asia/Seoul"),
        City("Tokyo", "TYO", "Asia/Tokyo"),
        City("Perth", "PER", "Australia/Perth"),
        City("Sydney", "SYD", "Australia/Sydney"),
        City("Melbourne", "MEL", "Australia/Melbourne"),
        City("Auckland", "AKL", "Pacific/Auckland"),
        City("Nouméa", "NOU", "Pacific/Noumea"),
        City("Papeete", "PPT", "Pacific/Tahiti"),
        City("Honolulu", "HNL", "Pacific/Honolulu"),
        City("Anchorage", "ANC", "America/Anchorage"),
        City("Vancouver", "YVR", "America/Vancouver"),
        City("Los Angeles", "LAX", "America/Los_Angeles"),
        City("Denver", "DEN", "America/Denver"),
        City("Mexico", "MEX", "America/Mexico_City"),
        City("Chicago", "CHI", "America/Chicago"),
        City("New York", "NYC", "America/New_York"),
        City("Montréal", "YUL", "America/Toronto"),
        City("La Havane", "HAV", "America/Havana"),
        City("Bogota", "BOG", "America/Bogota"),
        City("Lima", "LIM", "America/Lima"),
        City("Caracas", "CCS", "America/Caracas"),
        City("Fort-de-France", "FDF", "America/Martinique"),
        City("Cayenne", "CAY", "America/Cayenne"),
        City("Santiago", "SCL", "America/Santiago"),
        City("Buenos Aires", "BUE", "America/Argentina/Buenos_Aires"),
        City("São Paulo", "SAO", "America/Sao_Paulo"),
        City("UTC", "UTC", "UTC")
    )

    private val collator: Collator = Collator.getInstance(Locale.FRENCH)

    val all: List<City> = raw.sortedWith(Comparator<City> { a, b -> collator.compare(a.name, b.name) })

    fun names(): List<String> = all.map { "${it.name} (${it.code})" }

    fun indexOf(code: String): Int = all.indexOfFirst { it.code == code }.coerceAtLeast(0)

    fun byCode(code: String): City {
        return all.firstOrNull { it.code == code } ?: all.first { it.code == "NYC" }
    }
}

object ClockPrefs {

    private const val PREFS = "clock_prefs"
    private val DEFAULTS = arrayOf("NYC", "TYO", "LON")

    fun codes(context: Context, widgetId: Int): List<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return List(3) { i -> prefs.getString("w${widgetId}_c$i", DEFAULTS[i]) ?: DEFAULTS[i] }
    }

    fun cities(context: Context, widgetId: Int): List<City> {
        return codes(context, widgetId).map { Cities.byCode(it) }
    }

    fun save(context: Context, widgetId: Int, codes: List<String>) {
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        for ((i, code) in codes.withIndex()) {
            editor.putString("w${widgetId}_c$i", code)
        }
        editor.apply()
    }

    fun forget(context: Context, widgetId: Int) {
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        for (i in 0..2) editor.remove("w${widgetId}_c$i")
        editor.apply()
    }
}

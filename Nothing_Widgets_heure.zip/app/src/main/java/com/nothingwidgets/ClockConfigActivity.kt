package com.nothingwidgets

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

private class CityAdapter(context: Context, items: List<String>) :
    ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, items) {

    init {
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getView(position, convertView, parent)
        (view as? TextView)?.setTextColor(Color.WHITE)
        return view
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getDropDownView(position, convertView, parent)
        (view as? TextView)?.apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1C1C1C"))
        }
        return view
    }
}

class ClockConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private val spinners = ArrayList<Spinner>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val density = resources.displayMetrics.density
        val pad = (24 * density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = getString(R.string.config_title)
        title.textSize = 22f
        title.setTextColor(Color.WHITE)
        root.addView(title)

        val hint = TextView(this)
        hint.text = getString(R.string.config_hint)
        hint.textSize = 14f
        hint.setTextColor(Color.parseColor("#9A9A9A"))
        hint.setPadding(0, (8 * density).toInt(), 0, 0)
        root.addView(hint)

        val saved = ClockPrefs.codes(this, widgetId)
        val names = Cities.names()

        for (i in 0..2) {
            val label = TextView(this)
            label.text = getString(R.string.config_city, i + 1)
            label.textSize = 13f
            label.setTextColor(Color.parseColor("#9A9A9A"))
            label.setPadding(0, (24 * density).toInt(), 0, 0)
            root.addView(label)

            val spinner = Spinner(this)
            spinner.adapter = CityAdapter(this, names)
            spinner.setSelection(Cities.indexOf(saved[i]))
            root.addView(spinner)
            spinners.add(spinner)
        }

        val saveButton = Button(this)
        saveButton.text = getString(R.string.config_save)
        saveButton.setOnClickListener { save() }
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.topMargin = (32 * density).toInt()
        root.addView(saveButton, params)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun save() {
        val codes = spinners.map { Cities.all[it.selectedItemPosition].code }
        ClockPrefs.save(this, widgetId, codes)
        ClockRenderer.refresh(this)

        val result = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        setResult(RESULT_OK, result)
        finish()
    }
}

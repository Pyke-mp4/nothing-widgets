package com.nothingwidgets

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.provider.AlarmClock
import android.widget.RemoteViews
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object ClockRenderer {

    const val ACTION_TICK = "com.nothingwidgets.CLOCK_TICK"

    private val WHITE = Color.WHITE
    private val RED = Color.parseColor("#D71921")
    private val DIM = Color.parseColor("#262626")
    private val SEPARATOR = Color.parseColor("#3A3A3A")

    private val DAYS = arrayOf("LUN", "MAR", "MER", "JEU", "VEN", "SAM", "DIM")
    private val MONTHS = arrayOf(
        "JAN", "FEV", "MAR", "AVR", "MAI", "JUN", "JUL", "AOU", "SEP", "OCT", "NOV", "DEC"
    )

    fun refresh(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ClockWidgetProvider::class.java))
        for (id in ids) render(context, manager, id)
        if (ids.isNotEmpty()) scheduleNext(context)
    }

    fun scheduleNext(context: Context) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val next = (System.currentTimeMillis() / 60000L + 1L) * 60000L + 200L
        val pending = tickIntent(context)
        try {
            val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarms.canScheduleExactAlarms()
            if (canExact) {
                alarms.setExact(AlarmManager.RTC, next, pending)
            } else {
                alarms.set(AlarmManager.RTC, next, pending)
            }
        } catch (e: SecurityException) {
            alarms.set(AlarmManager.RTC, next, pending)
        }
    }

    fun cancel(context: Context) {
        val alarms = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarms.cancel(tickIntent(context))
    }

    private fun tickIntent(context: Context): PendingIntent {
        val intent = Intent(context, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(
            context,
            1,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val options = manager.getAppWidgetOptions(id)
        val density = context.resources.displayMetrics.density

        var widthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (widthDp <= 0) widthDp = 320
        if (heightDp <= 0) heightDp = 170

        var scale = density
        val maxPixels = 1_400_000f
        val pixels = widthDp * scale * heightDp * scale
        if (pixels > maxPixels) {
            scale *= Math.sqrt((maxPixels / pixels).toDouble()).toFloat()
        }

        val width = (widthDp * scale).roundToInt()
        val height = (heightDp * scale).roundToInt()
        val bitmap = draw(context, id, width, height, scale)

        val views = RemoteViews(context.packageName, R.layout.widget_clock)
        views.setImageViewBitmap(R.id.clock_image, bitmap)

        val alarmIntent = Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pending = PendingIntent.getActivity(
            context,
            0,
            alarmIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.clock_image, pending)

        manager.updateAppWidget(id, views)
    }

    private fun timeIn(zone: ZoneId): String {
        val t = ZonedDateTime.now(zone)
        return String.format(Locale.US, "%02d:%02d", t.hour, t.minute)
    }

    private fun draw(context: Context, id: Int, w: Int, h: Int, base: Float): Bitmap {
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.color = Color.BLACK
        val radius = min(28f * base, h / 2f)
        canvas.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), radius, radius, bg)

        val sc = base * min(1f, min(h / (150f * base), w / (300f * base)))
        val pad = 18f * sc

        val paris = ZoneId.of("Europe/Paris")
        val now = ZonedDateTime.now(paris)
        val parisTime = String.format(Locale.US, "%02d:%02d", now.hour, now.minute)
        val dayName = DAYS[now.dayOfWeek.value - 1]
        val monthName = MONTHS[now.monthValue - 1]
        val date = dayName + " " + String.format(Locale.US, "%02d", now.dayOfMonth) + " " + monthName

        val cities = ClockPrefs.cities(context, id)

        val smallCell = 2.6f * sc
        val labelCols = DotFont.columns("AAA")
        val timeCols = DotFont.columns("00:00")
        val rightWidth = (labelCols + 3 + timeCols) * smallCell
        val x0 = w - pad - rightWidth
        val sepX = x0 - 14f * sc

        val sepPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        sepPaint.color = SEPARATOR
        var sy = pad + 8f * sc
        while (sy < h - pad - 8f * sc) {
            canvas.drawCircle(sepX, sy, 0.8f * sc, sepPaint)
            sy += 5f * sc
        }

        val area = h - 2f * pad
        for (i in 0..2) {
            val city = cities[i]
            val centerY = pad + area * (2 * i + 1) / 6f
            val textY = centerY - 3.5f * smallCell
            DotFont.draw(canvas, city.code, x0, textY, smallCell, WHITE, RED, "", Color.TRANSPARENT)
            DotFont.draw(
                canvas,
                timeIn(city.zone),
                x0 + (labelCols + 3) * smallCell,
                textY,
                smallCell,
                WHITE,
                RED,
                ":",
                Color.TRANSPARENT
            )
        }

        val cityCell = 2.4f * sc
        DotFont.draw(canvas, "PARIS", pad, pad, cityCell, WHITE, RED, "", Color.TRANSPARENT)

        val dateCell = 2.2f * sc
        val dateY = h - pad - DotFont.height(dateCell)
        DotFont.draw(canvas, date, pad, dateY, dateCell, WHITE, RED, "", Color.TRANSPARENT)

        val availWidth = sepX - 12f * sc - pad
        val topFree = pad + DotFont.height(cityCell) + 6f * sc
        val bottomFree = dateY - 6f * sc
        val cellByHeight = max(bottomFree - topFree, 1f) / 7f
        val cell = min(availWidth / timeCols, cellByHeight)
        val timeY = (h - DotFont.height(cell)) / 2f
        DotFont.draw(canvas, parisTime, pad, timeY, cell, WHITE, RED, ":", DIM)

        return bitmap
    }
}

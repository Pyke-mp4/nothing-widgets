package com.nothingwidgets

import android.graphics.Canvas
import android.graphics.Paint

object DotFont {

    private const val ROWS = 7

    private val glyphs: Map<Char, Array<String>> = mapOf(
        '0' to arrayOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
        '1' to arrayOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
        '2' to arrayOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
        '3' to arrayOf("11110", "00001", "00001", "01110", "00001", "00001", "11110"),
        '4' to arrayOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
        '5' to arrayOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
        '6' to arrayOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
        '7' to arrayOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
        '8' to arrayOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
        '9' to arrayOf("01110", "10001", "10001", "01111", "00001", "00010", "01100"),
        ':' to arrayOf("0", "0", "1", "0", "1", "0", "0"),
        '-' to arrayOf("00000", "00000", "00000", "11111", "00000", "00000", "00000"),
        '°' to arrayOf("111", "101", "111", "000", "000", "000", "000"),
        ' ' to arrayOf("000", "000", "000", "000", "000", "000", "000"),
        'A' to arrayOf("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
        'B' to arrayOf("11110", "10001", "10001", "11110", "10001", "10001", "11110"),
        'C' to arrayOf("01110", "10001", "10000", "10000", "10000", "10001", "01110"),
        'D' to arrayOf("11110", "10001", "10001", "10001", "10001", "10001", "11110"),
        'E' to arrayOf("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
        'F' to arrayOf("11111", "10000", "10000", "11110", "10000", "10000", "10000"),
        'G' to arrayOf("01110", "10001", "10000", "10111", "10001", "10001", "01111"),
        'H' to arrayOf("10001", "10001", "10001", "11111", "10001", "10001", "10001"),
        'I' to arrayOf("01110", "00100", "00100", "00100", "00100", "00100", "01110"),
        'J' to arrayOf("00111", "00010", "00010", "00010", "00010", "10010", "01100"),
        'K' to arrayOf("10001", "10010", "10100", "11000", "10100", "10010", "10001"),
        'L' to arrayOf("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
        'M' to arrayOf("10001", "11011", "10101", "10101", "10001", "10001", "10001"),
        'N' to arrayOf("10001", "11001", "10101", "10011", "10001", "10001", "10001"),
        'O' to arrayOf("01110", "10001", "10001", "10001", "10001", "10001", "01110"),
        'P' to arrayOf("11110", "10001", "10001", "11110", "10000", "10000", "10000"),
        'Q' to arrayOf("01110", "10001", "10001", "10001", "10101", "10010", "01101"),
        'R' to arrayOf("11110", "10001", "10001", "11110", "10100", "10010", "10001"),
        'S' to arrayOf("01111", "10000", "10000", "01110", "00001", "00001", "11110"),
        'T' to arrayOf("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
        'U' to arrayOf("10001", "10001", "10001", "10001", "10001", "10001", "01110"),
        'V' to arrayOf("10001", "10001", "10001", "10001", "10001", "01010", "00100"),
        'W' to arrayOf("10001", "10001", "10001", "10101", "10101", "11011", "10001"),
        'X' to arrayOf("10001", "10001", "01010", "00100", "01010", "10001", "10001"),
        'Y' to arrayOf("10001", "10001", "01010", "00100", "00100", "00100", "00100"),
        'Z' to arrayOf("11111", "00001", "00010", "00100", "01000", "10000", "11111")
    )

    private val fallback = glyphs.getValue('-')

    private fun glyphOf(c: Char): Array<String> = glyphs[c] ?: fallback

    fun columns(text: String): Int {
        var cols = 0
        for ((i, c) in text.withIndex()) {
            cols += glyphOf(c)[0].length
            if (i < text.length - 1) cols += 1
        }
        return cols
    }

    fun width(text: String, cell: Float): Float = columns(text) * cell

    fun height(cell: Float): Float = ROWS * cell

    fun draw(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        cell: Float,
        onColor: Int,
        accentColor: Int,
        accentChars: String,
        dimColor: Int
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val radius = cell * 0.36f
        var col = 0
        for (c in text) {
            val glyph = glyphOf(c)
            val on = if (accentChars.indexOf(c) >= 0) accentColor else onColor
            for (r in 0 until ROWS) {
                val row = glyph[r]
                for (k in row.indices) {
                    paint.color = if (row[k] == '1') on else dimColor
                    canvas.drawCircle(
                        x + (col + k + 0.5f) * cell,
                        y + (r + 0.5f) * cell,
                        radius,
                        paint
                    )
                }
            }
            col += glyph[0].length + 1
        }
    }
}

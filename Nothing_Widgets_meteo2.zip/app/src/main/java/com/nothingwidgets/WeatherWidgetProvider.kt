package com.nothingwidgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.widget.RemoteViews
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class WeatherWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.nothingwidgets.REFRESH_WEATHER"

        private val WHITE = Color.WHITE
        private val RED = Color.parseColor("#D71921")
        private val DIM = Color.parseColor("#262626")
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        renderAll(context, appWidgetManager, appWidgetIds)

        val pending = goAsync()
        Thread {
            try {
                if (WeatherRepo.fetch(context)) {
                    renderAll(context, appWidgetManager, appWidgetIds)
                }
            } catch (e: Exception) {
            } finally {
                pending?.finish()
            }
        }.start()
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_REFRESH) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, WeatherWidgetProvider::class.java)
            )
            onUpdate(context, manager, ids)
        } else {
            super.onReceive(context, intent)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        newOptions: Bundle
    ) {
        render(context, appWidgetManager, appWidgetId)
    }

    private fun renderAll(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) render(context, manager, id)
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int) {
        val options = manager.getAppWidgetOptions(id)
        val density = context.resources.displayMetrics.density

        var widthDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
        var heightDp = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
        if (widthDp <= 0) widthDp = 160
        if (heightDp <= 0) heightDp = 180

        var scale = density
        val maxPixels = 1_400_000f
        val pixels = widthDp * scale * heightDp * scale
        if (pixels > maxPixels) {
            scale *= Math.sqrt((maxPixels / pixels).toDouble()).toFloat()
        }

        val width = (widthDp * scale).roundToInt()
        val height = (heightDp * scale).roundToInt()
        val bitmap = draw(context, width, height, scale, WeatherRepo.load(context))

        val views = RemoteViews(context.packageName, R.layout.widget_weather)
        views.setImageViewBitmap(R.id.weather_image, bitmap)

        val intent = Intent(context, WeatherWidgetProvider::class.java).setAction(ACTION_REFRESH)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.weather_image, pendingIntent)

        manager.updateAppWidget(id, views)
    }

    private fun draw(
        context: Context,
        w: Int,
        h: Int,
        sc: Float,
        data: WeatherData?
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        bg.color = Color.BLACK
        val radius = min(28f * sc, h / 2f)
        canvas.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), radius, radius, bg)

        if (w < 1.45f * h) {
            drawCompact(context, canvas, w, h, sc, data)
        } else {
            drawWide(context, canvas, w, h, sc, data)
        }
        return bitmap
    }

    private fun tempTextOf(data: WeatherData?): String {
        return if (data == null) "--°" else "${data.temp.roundToInt()}°"
    }

    private fun drawCompact(
        context: Context,
        canvas: Canvas,
        w: Int,
        h: Int,
        base: Float,
        data: WeatherData?
    ) {
        val k = min(1f, min(h / (175f * base), w / (150f * base)))
        val sc = base * k
        val pad = 14f * sc

        DotFont.draw(canvas, "PARIS", pad, pad, 2.2f * sc, WHITE, RED, "", Color.TRANSPARENT)

        val rowH = 18f * sc
        val rowGap = 4f * sc
        val timeCell = 2.3f * sc
        val iconSmall = 18f * sc
        val gapIcon = 6f * sc
        val sunrise = data?.sunrise ?: "--:--"
        val sunset = data?.sunset ?: "--:--"

        val row2Y = h - pad - rowH
        val row1Y = row2Y - rowGap - rowH
        drawTimeRow(context, canvas, R.drawable.ic_sunrise, sunrise, pad, row1Y, rowH, iconSmall, gapIcon, timeCell)
        drawTimeRow(context, canvas, R.drawable.ic_sunset, sunset, pad, row2Y, rowH, iconSmall, gapIcon, timeCell)

        val iconSize = 44f * sc
        if (data != null) {
            drawIcon(context, iconFor(data.code, data.isDay), canvas, w - pad - iconSize, pad, iconSize)
        }

        val areaTop = pad + iconSize + 2f * sc
        val areaBottom = row1Y - 6f * sc
        val areaH = max(areaBottom - areaTop, 1f)

        val tempText = tempTextOf(data)
        val cellByWidth = (w - 2f * pad) / DotFont.columns(tempText)
        val tempCell = min(min(11f * sc, areaH * 0.85f / 7f), cellByWidth)
        val tempY = areaTop + (areaH - DotFont.height(tempCell)) / 2f
        DotFont.draw(canvas, tempText, pad, tempY, tempCell, WHITE, RED, "°", DIM)
    }

    private fun drawWide(
        context: Context,
        canvas: Canvas,
        w: Int,
        h: Int,
        sc: Float,
        data: WeatherData?
    ) {
        val pad = 18f * sc

        val cityCell = 2.4f * sc
        DotFont.draw(canvas, "PARIS", pad, pad, cityCell, WHITE, RED, "", Color.TRANSPARENT)

        val rowH = 20f * sc
        val rowY = h - pad - rowH
        val timeCell = 2.5f * sc
        val iconSmall = 20f * sc
        val gapIcon = 6f * sc

        val sunrise = data?.sunrise ?: "--:--"
        val sunset = data?.sunset ?: "--:--"

        var x = pad
        drawTimeRow(context, canvas, R.drawable.ic_sunrise, sunrise, x, rowY, rowH, iconSmall, gapIcon, timeCell)
        x += iconSmall + gapIcon + DotFont.width(sunrise, timeCell) + 20f * sc
        drawTimeRow(context, canvas, R.drawable.ic_sunset, sunset, x, rowY, rowH, iconSmall, gapIcon, timeCell)

        val areaTop = pad + DotFont.height(cityCell) + 6f * sc
        val areaBottom = rowY - 6f * sc
        val areaH = max(areaBottom - areaTop, 1f)

        val tempText = tempTextOf(data)
        val iconSize = min(areaH * 0.9f, 80f * sc)
        val availWidth = w - 2f * pad - iconSize - 8f * sc
        val cellByWidth = availWidth / DotFont.columns(tempText)
        val tempCell = min(min(11f * sc, areaH * 0.8f / 7f), cellByWidth)
        val tempY = areaTop + (areaH - DotFont.height(tempCell)) / 2f
        DotFont.draw(canvas, tempText, pad, tempY, tempCell, WHITE, RED, "°", DIM)

        if (data != null) {
            val iconX = w - pad - iconSize
            val iconY = areaTop + (areaH - iconSize) / 2f
            drawIcon(context, iconFor(data.code, data.isDay), canvas, iconX, iconY, iconSize)
        }
    }

    private fun drawTimeRow(
        context: Context,
        canvas: Canvas,
        iconRes: Int,
        time: String,
        x: Float,
        y: Float,
        rowH: Float,
        iconSize: Float,
        gap: Float,
        cell: Float
    ) {
        drawIcon(context, iconRes, canvas, x, y + (rowH - iconSize) / 2f, iconSize)
        val textY = y + (rowH - DotFont.height(cell)) / 2f
        DotFont.draw(canvas, time, x + iconSize + gap, textY, cell, WHITE, RED, ":", Color.TRANSPARENT)
    }

    private fun drawIcon(
        context: Context,
        resId: Int,
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float
    ) {
        val drawable = context.getDrawable(resId) ?: return
        drawable.setBounds(x.roundToInt(), y.roundToInt(), (x + size).roundToInt(), (y + size).roundToInt())
        drawable.draw(canvas)
    }

    private fun iconFor(code: Int, isDay: Boolean): Int {
        return when (code) {
            0, 1 -> if (isDay) R.drawable.ic_sun else R.drawable.ic_moon
            2 -> if (isDay) R.drawable.ic_partly else R.drawable.ic_cloud
            3 -> R.drawable.ic_cloud
            45, 48 -> R.drawable.ic_fog
            51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.ic_rain
            71, 73, 75, 77, 85, 86 -> R.drawable.ic_snow
            95, 96, 99 -> R.drawable.ic_storm
            else -> R.drawable.ic_cloud
        }
    }
}

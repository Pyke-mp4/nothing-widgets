package com.nothingwidgets

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val padding = (24 * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            text = getString(R.string.main_help)
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(padding, padding, padding, padding)
            typeface = Typeface.create(resources.getFont(R.font.doto), Typeface.NORMAL)
        }
        setContentView(view)
    }
}

package com.nothingwidgets

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WeatherData(
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val sunrise: String,
    val sunset: String
)

object WeatherRepo {

    private const val PREFS = "weather_cache"

    private const val API_URL =
        "https://api.open-meteo.com/v1/forecast" +
            "?latitude=48.8566&longitude=2.3522" +
            "&current=temperature_2m,weather_code,is_day" +
            "&daily=sunrise,sunset" +
            "&timezone=Europe%2FParis&forecast_days=1"

    fun load(context: Context): WeatherData? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.contains("temp")) return null
        return WeatherData(
            temp = prefs.getFloat("temp", 0f).toDouble(),
            code = prefs.getInt("code", 3),
            isDay = prefs.getBoolean("day", true),
            sunrise = prefs.getString("sunrise", "--:--") ?: "--:--",
            sunset = prefs.getString("sunset", "--:--") ?: "--:--"
        )
    }

    fun fetch(context: Context): Boolean {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(API_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            if (conn.responseCode != 200) return false

            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val current = json.getJSONObject("current")
            val daily = json.getJSONObject("daily")

            val temp = current.getDouble("temperature_2m")
            val code = current.getInt("weather_code")
            val isDay = current.getInt("is_day") == 1
            val sunrise = daily.getJSONArray("sunrise").getString(0).substringAfter('T')
            val sunset = daily.getJSONArray("sunset").getString(0).substringAfter('T')

            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat("temp", temp.toFloat())
                .putInt("code", code)
                .putBoolean("day", isDay)
                .putString("sunrise", sunrise)
                .putString("sunset", sunset)
                .apply()
            return true
        } catch (e: Exception) {
            return false
        } finally {
            conn?.disconnect()
        }
    }
}
